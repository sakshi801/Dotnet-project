﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace blood_donation
{
    public partial class patientdetails3 : System.Web.UI.Page
    {

        string conn = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                display();
            }
        }

        void display()
        {
            SqlConnection cn = new SqlConnection(conn);
            SqlCommand cmd = new SqlCommand("select d.id, d.name as Patient_Name,d.Gender,d.age as Age,d.Weight,d.mob as Mobile_Number,d.email as Email,d.guarname as Guardian_Name,d.gmob as Guardian_MobileNumber,g.GroupName as BloodGroup,d.country as Country,d.state as State,d.city as City,d.aadhar as AadharId,t.BloodName as BloodType,d.Date from Patient_table d join BloodGroup g on d.bloodgp=g.Id join BloodType t on d.BloodType=t.Id", cn);
            cn.Open();
            SqlDataAdapter adop = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adop.Fill(ds);
            GridView1.DataSource = ds;

            GridView1.DataBind();
        }
    }
}