﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace blood_donation
{
    public partial class adminpatientop : System.Web.UI.Page
    {
        string conn = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                dropbgbind();
                dropbtbind();
                Bind();
            }

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection cn = new SqlConnection(conn);
            SqlCommand cmd = new SqlCommand("insert into Patient_table(name,Gender,age,Weight,mob,email,guarname,gmob,bloodgp,country,state,city,aadhar,BloodType,Date) values(' " + dname.Text + " ', ' " + RadioButtonList1.Text + " ', ' " + age.Text + " ', ' " + weigh.Text + " ', ' " + mob.Text + " ',' " + email.Text + " ',' " + gname.Text + " ', ' " + mobile.Text + " ', ' " + dropbg.SelectedValue + " ', ' " + DropDownList1.Text + " ', ' " + DropDownList2.Text + " ', ' " + DropDownList3.Text + " ', ' " + aadhar.Text + " ',' " + Dropbt.SelectedValue + " ',' " + date.Text + " ')", cn);
            cn.Open();

            int i = cmd.ExecuteNonQuery();
            if (i > 0)
            {

                
                dname.Text = "";
                age.Text = "";
                weigh.Text = "";
                mob.Text = "";
                email.Text = "";
                gname.Text = "";
                mobile.Text = "";
                aadhar.Text = "";
                date.Text = "";

            }
        }
        void dropbgbind()
        {
            SqlConnection cn = new SqlConnection(conn);
            SqlCommand cmd = new SqlCommand("select * from BloodGroup", cn);
            cn.Open();
            SqlDataAdapter adop = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adop.Fill(ds);
            dropbg.DataSource = ds;
            dropbg.DataTextField = "GroupName";
            dropbg.DataValueField = "Id";
            dropbg.DataBind();
            dropbg.Items.Insert(0, new ListItem("--Select blood group--", "0"));

        }

        void dropbtbind()
        {
            SqlConnection cn = new SqlConnection(conn);
            SqlCommand cmd = new SqlCommand("select * from BloodType", cn);
            cn.Open();
            SqlDataAdapter adop = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adop.Fill(ds);
            Dropbt.DataSource = ds;
            Dropbt.DataTextField = "BloodName";
            Dropbt.DataValueField = "Id";
            Dropbt.DataBind();
            Dropbt.Items.Insert(0, new ListItem("--Select blood type--", "0"));

        }
        public void Bind()
        {
            SqlDataAdapter ad = new SqlDataAdapter("select d.id, d.name,d.Gender,d.age,d.Weight,d.mob,d.email,d.guarname,d.gmob,g.GroupName,d.country,d.state,d.city ,d.aadhar,t.BloodName as BloodType,d.Date from Patient_table d join BloodGroup g on d.bloodgp=g.id join BloodType t on d.BloodType=t.id ", conn);
            DataTable dt = new DataTable();
            ad.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }
        protected void deleteclk(object sender, EventArgs e)
        {
            int ID = int.Parse((sender as LinkButton).CommandArgument);
            SqlConnection cn = new SqlConnection(conn);
            cn.Open();
            SqlCommand cnd = new SqlCommand("delete from Patient_table where id='" + ID + "'", cn);
            int i = cnd.ExecuteNonQuery();
            Bind();
            dname.Text = "";
            age.Text = "";
            weigh.Text = "";
            mob.Text = "";
            email.Text = "";
            gname.Text = "";
            mobile.Text = "";
            aadhar.Text = "";
            date.Text = "";
            
        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;
            Bind();
            dname.Text = "";
            age.Text = "";
            weigh.Text = "";
            mob.Text = "";
            email.Text = "";
            gname.Text = "";
            mobile.Text = "";
            aadhar.Text = "";
            date.Text = "";
            
        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GridView1.EditIndex = -1;
            Bind();
        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            Label id = GridView1.Rows[e.RowIndex].FindControl("lbl1") as Label;
            TextBox namee = (TextBox)GridView1.Rows[e.RowIndex].FindControl("Txt1");
            TextBox genderr = (TextBox)GridView1.Rows[e.RowIndex].FindControl("Txt2");
            TextBox age = (TextBox)GridView1.Rows[e.RowIndex].FindControl("Txt3");
            TextBox weight = (TextBox)GridView1.Rows[e.RowIndex].FindControl("Txt4");
            TextBox mob = (TextBox)GridView1.Rows[e.RowIndex].FindControl("Txt5");
            TextBox email = (TextBox)GridView1.Rows[e.RowIndex].FindControl("Txt6");
            TextBox garname = (TextBox)GridView1.Rows[e.RowIndex].FindControl("Txt7");
            TextBox garmob = (TextBox)GridView1.Rows[e.RowIndex].FindControl("Txt8");
            TextBox bloodgp = (TextBox)GridView1.Rows[e.RowIndex].FindControl("Txt9");
            TextBox country = (TextBox)GridView1.Rows[e.RowIndex].FindControl("Txt10");
            TextBox state = (TextBox)GridView1.Rows[e.RowIndex].FindControl("Txt11");
            TextBox city = (TextBox)GridView1.Rows[e.RowIndex].FindControl("Txt12");
            TextBox aadhar = (TextBox)GridView1.Rows[e.RowIndex].FindControl("Txt13");
            TextBox bloodtype = (TextBox)GridView1.Rows[e.RowIndex].FindControl("Txt14");
            TextBox date = (TextBox)GridView1.Rows[e.RowIndex].FindControl("Txt15");
            SqlConnection cn = new SqlConnection(conn);
            cn.Open();
            SqlCommand cmmd = new SqlCommand("update Patient_table set name='" + namee.Text + "',Gender='" + genderr.Text + "',age='" + int.Parse(age.Text) + "',Weight='" + weight.Text + "',mob='" + mob.Text + "',email='" + email.Text + "',guarname='" + garname.Text + "',gmob='" + garmob.Text + "',country='" + country.Text + "',state='" + state.Text + "',city='" + city.Text + "',aadhar='" + aadhar.Text + "',Date='" + date.Text + "' where id='" + id.Text + "'", cn);
            cmmd.ExecuteNonQuery();
            GridView1.EditIndex = -1;
            Bind();
        }
        protected void Button3_Click(object sender, EventArgs e)
        {
            SqlDataAdapter ad = new SqlDataAdapter("select d.id, d.name,d.Gender,d.age,d.Weight,d.mob,d.email,d.guarname,d.gmob,g.GroupName,d.country,d.state,d.city ,d.aadhar,t.BloodName as BloodType,d.Date from Patient_table d join BloodGroup g on d.bloodgp=g.id join BloodType t on d.BloodType=t.id", conn);
            DataTable dt = new DataTable();
            ad.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
            dname.Text = "";
            age.Text = "";
            weigh.Text = "";
            mob.Text = "";
            email.Text = "";
            gname.Text = "";
            mobile.Text = "";
            aadhar.Text = "";
            date.Text = "";
            
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            //string aadhar = TextBox1.Text;
            SqlDataAdapter ad = new SqlDataAdapter("select d.id, d.name,d.Gender,d.age,d.Weight,d.mob,d.email,d.guarname,d.gmob,g.GroupName,d.country,d.state,d.city ,d.aadhar,t.BloodName as BloodType,d.Date from Patient_table d join BloodGroup g on d.bloodgp=g.id join BloodType t on d.BloodType=t.id where d.aadhar=' " + TextBox1.Text + " ' ", conn);
            DataTable dt = new DataTable();
            ad.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
            dname.Text = "";
            age.Text = "";
            weigh.Text = "";
            mob.Text = "";
            email.Text = "";
            gname.Text = "";
            mobile.Text = "";
            
            date.Text = "";
            
        }
    }
}