﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace blood_donation
{
    public partial class searchblood : System.Web.UI.Page
    {
        string conn = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
        string bg;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                dropbgbind();


            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            string a = Dropbgrp.SelectedValue;

            if (a == "1")
            {
                bg = "A+";
            }
            else if (a == "2")
            {
                bg = "O+";
            }
            else if (a == "3")
            {
                bg = "B+";
            }
            else if (a == "4")
            {
                bg = "AB+";
            }
            else if (a == "5")
            {
                bg = "A-";
            }
            else if (a == "6")
            {
                bg = "O-";
            }
            else if (a == "7")
            {
                bg = "B-";
            }
            else if (a == "8")
            {
                bg = "AB-";
            }
            SqlConnection cn = new SqlConnection(conn);
            cn.Open();
            SqlCommand cdd = new SqlCommand("select Quantity from BloodBank where BloodGroup='" + bg + "'", cn);
            int quantt = (int)cdd.ExecuteScalar();
            if (quantt == 0)
            {
                Label1.Text = "Blood Not Available";
                

            }
            else
            {
                Label1.Text = "Blood Available";
            }
        }
            void dropbgbind()
            {
                SqlConnection cn = new SqlConnection(conn);
                SqlCommand cmd = new SqlCommand("select * from BloodGroup", cn);
                cn.Open();
                SqlDataAdapter adop = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                adop.Fill(ds);
                Dropbgrp.DataSource = ds;
                Dropbgrp.DataTextField = "GroupName";
                Dropbgrp.DataValueField = "Id";
                Dropbgrp.DataBind();
            }




        }
}
