﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace blood_donation
{
    public partial class Newpatreg3 : System.Web.UI.Page
    {
        string conn = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            {
                if (!IsPostBack)
                {
                    dropbgbind();
                    dropbtbind();
                }
            }

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection cn = new SqlConnection(conn);
            SqlCommand cmd = new SqlCommand("insert into Patient_table(name,Gender,age,Weight,mob,email,guarname,gmob,bloodgp,country,state,city,aadhar,BloodType,Date) values(' " + dname.Text + " ', ' " + RadioButtonList1.Text + " ', ' " + age.Text + " ', ' " + weigh.Text + " ', ' " + mob.Text + " ',' " + email.Text + " ', ' " + gname.Text + " ',' " + mobile.Text + " ',' " + dropbg.SelectedValue+ " ', ' " + DropDownList1.Text + " ', ' " + DropDownList2.Text + " ', ' " + DropDownList3.Text + " ', ' " + aadhar.Text + " ' , ' " + Dropbt.SelectedValue + " ' , ' " + date.Text + " ')", cn);
            cn.Open();

            int i = cmd.ExecuteNonQuery();
            if (i > 0)
            {

                Response.Redirect("patientresponse.aspx");


            }
        }


        void dropbgbind()
        {
            SqlConnection cn = new SqlConnection(conn);
            SqlCommand cmd = new SqlCommand("select * from BloodGroup", cn);
            cn.Open();
            SqlDataAdapter adop = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adop.Fill(ds);
            dropbg.DataSource = ds;
            dropbg.DataTextField = "GroupName";
            dropbg.DataValueField = "Id";
            dropbg.DataBind();
        }

        void dropbtbind()
        {
            SqlConnection cn = new SqlConnection(conn);
            SqlCommand cmd = new SqlCommand("select * from BloodType", cn);
            cn.Open();
            SqlDataAdapter adop = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adop.Fill(ds);
            Dropbt.DataSource = ds;
            Dropbt.DataTextField = "BloodName";
            Dropbt.DataValueField = "Id";
            Dropbt.DataBind();
        }

    }
}