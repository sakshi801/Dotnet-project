﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace blood_donation
{
    public partial class upd : System.Web.UI.Page
    {
        string conn = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string a = DropDownList1.SelectedItem.Value;
            SqlConnection cn = new SqlConnection(conn);
            cn.Open();

            if (a == "name")
            {
                SqlCommand cmd = new SqlCommand("update Donor_table set name='" + TextBox1.Text + "'where aadhar='" + TextBox2.Text + "'", cn);
                cmd.ExecuteNonQuery();
                Label3.Text = "Sucessfully Updated";
            }
            else if (a == "age")
            {
                SqlCommand cmd = new SqlCommand("update Donor_table set age='" + int.Parse(TextBox1.Text) + "'where aadhar='" + TextBox2.Text + "'", cn);
                cmd.ExecuteNonQuery();

                Label3.Text = "Sucessfully Updated";//Label3.Text = "sucess";
            }
            else if (a == "mobile")
            {
                SqlCommand cmd = new SqlCommand("update Donor_table set mob='" + int.Parse(TextBox1.Text) + "'where aadhar='" + TextBox2.Text + "'", cn);
                cmd.ExecuteNonQuery();
                Label3.Text = "Sucessfully Updated";
            }
            else if (a == "email")
            {
                SqlCommand cmd = new SqlCommand("update Donor_table set email='" + TextBox1.Text + "'where aadhar='" + TextBox2.Text + "'", cn);
                cmd.ExecuteNonQuery();
                Label3.Text = "Sucessfully Updated";
            }
            else if (a == "bloodgp")
            {
                SqlCommand cmd = new SqlCommand("update Donor_table set bloodgp='" + TextBox1.Text + "'where aadhar='" + TextBox2.Text + "'", cn);
                cmd.ExecuteNonQuery();
                Label3.Text = "Sucessfully Updated";
            }
            else if (a == "country")
            {
                SqlCommand cmd = new SqlCommand("update Donor_table set country='" + TextBox1.Text + "'where aadhar='" + TextBox2.Text + "'", cn);
                cmd.ExecuteNonQuery();
                Label3.Text = "Sucessfully Updated";
            }
            else if (a == "state")
            {
                SqlCommand cmd = new SqlCommand("update Donor_table set state='" + TextBox1.Text + "'where aadhar='" + TextBox2.Text + "'", cn);
                cmd.ExecuteNonQuery();
                Label3.Text = "Sucessfully Updated";
            }
            else if (a == "city")
            {
                SqlCommand cmd = new SqlCommand("update Donor_table set city='" + TextBox1.Text + "'where aadhar='" + TextBox2.Text + "'", cn);
                cmd.ExecuteNonQuery();
                Label3.Text = "Sucessfully Updated";
            }
        }
    }
}