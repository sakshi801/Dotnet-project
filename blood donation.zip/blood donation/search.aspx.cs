﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace blood_donation
{
    public partial class Searchblood : System.Web.UI.Page
    {

        string conn = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                dropbgbind();
               
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            string a = Dropbgrp.SelectedItem.Value;
            SqlConnection cn = new SqlConnection(conn);
            cn.Open();
            SqlCommand cmd = new SqlCommand("select * from BloodBank where BloodGroup='"+a+"'   ", cn);
            int i=cmd.ExecuteNonQuery();
            if(i>0)
            { 
            Label1.Text = "Blood Available";
            }
            else
            {
                Label1.Text = "Blood not Available";
            }
        }
        void dropbgbind()
        {
            SqlConnection cn = new SqlConnection(conn);
            SqlCommand cmd = new SqlCommand("select * from BloodGroup", cn);
            cn.Open();
            SqlDataAdapter adop = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adop.Fill(ds);
            Dropbgrp.DataSource = ds;
            Dropbgrp.DataTextField = "GroupName";
            Dropbgrp.DataValueField = "Id";
            Dropbgrp.DataBind();
        }

        

    }
}