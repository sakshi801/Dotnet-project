﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace blood_donation
{
    public partial class donorreport : System.Web.UI.Page
    {
        string conn = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                display();
            }
        }

        void display()
        {
            SqlConnection cn = new SqlConnection(conn);
            SqlCommand cmd = new SqlCommand("select d.id, d.name as Donor_Name, d.Gender, d.age as Age, d.Weight, d.mob as Mobile_Number, d.email as Email, g.GroupName as BloodGroup, q.Quantity, q.Unit, d.country as Country, d.state as State, d.city as City, d.aadhar as AadharId, t.BloodName as BloodType, d.Date from Donor_table d join BloodGroup g on d.bloodgp = g.Id join BloodType t on d.BloodType = t.Id join InBlood q on d.id = q.Donorid", cn);
            cn.Open();
            SqlDataAdapter adop = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adop.Fill(ds);
            GridView1.DataSource = ds;

            GridView1.DataBind();
        }

        //protected void Button1_Click(object sender, EventArgs e)
        //{
        //   // string name = TextBox1.Text;
        //    SqlConnection cn = new SqlConnection(conn);
        //    SqlCommand cmd = new SqlCommand("select d.id, d.name as Donor_Name, d.Gender, d.age as Age, d.Weight, d.mob as Mobile_Number, d.email as Email, g.GroupName as BloodGroup, q.Quantity, q.Unit, d.country as Country, d.state as State, d.city as City, d.aadhar as AadharId, t.BloodName as BloodType, d.Date from Donor_table d join BloodGroup g on d.bloodgp = g.Id join BloodType t on d.BloodType = t.Id join InBlood q on d.id = q.Donorid  where d.name = '" + TextBox1.Text + "' ", cn);
        //    cn.Open();
        //    SqlDataAdapter adop = new SqlDataAdapter(cmd);
        //    DataSet ds = new DataSet();
        //    adop.Fill(ds);
        //    GridView1.DataSource = ds;

        //    GridView1.DataBind();
        //}

        protected void Button1_Click1(object sender, EventArgs e)
        {
            SqlConnection cn = new SqlConnection(conn);
            SqlCommand cmd = new SqlCommand("select d.id, d.name as Donor_Name, d.Gender, d.age as Age, d.Weight, d.mob as Mobile_Number, d.email as Email, g.GroupName as BloodGroup, q.Quantity, q.Unit, d.country as Country, d.state as State, d.city as City, d.aadhar as AadharId, t.BloodName as BloodType, d.Date from Donor_table d join BloodGroup g on d.bloodgp = g.Id join BloodType t on d.BloodType = t.Id join InBlood q on d.id = q.Donorid  where d.name = '" + TextBox1.Text + "' ", cn);
            cn.Open();
            SqlDataAdapter adop = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adop.Fill(ds);
            GridView1.DataSource = ds;

            GridView1.DataBind();

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            SqlConnection cn = new SqlConnection(conn);
            SqlCommand cmd = new SqlCommand("select d.id, d.name as Donor_Name, d.Gender, d.age as Age, d.Weight, d.mob as Mobile_Number, d.email as Email, g.GroupName as BloodGroup, q.Quantity, q.Unit, d.country as Country, d.state as State, d.city as City, d.aadhar as AadharId, t.BloodName as BloodType, d.Date from Donor_table d join BloodGroup g on d.bloodgp = g.Id join BloodType t on d.BloodType = t.Id join InBlood q on d.id = q.Donorid", cn);
            cn.Open();
            SqlDataAdapter adop = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adop.Fill(ds);
            GridView1.DataSource = ds;

            GridView1.DataBind();

        }
    }
}
