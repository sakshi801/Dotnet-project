﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace blood_donation
{
    public partial class patientreg1 : System.Web.UI.Page
    {

        string conn = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection cn = new SqlConnection(conn);
            SqlCommand cmd = new SqlCommand("insert into Donor_table(name,Gender,age,mob,email,bloodgp,country,state,city,aadhar) values(' " + dname.Text + " ', ' " + RadioButtonList1.Text + " ', ' " + age.Text + " ', ' " + mob.Text + " ',' " + email.Text + " ', ' " + bg.Text + " ', ' " + DropDownList1.Text + " ', ' " + DropDownList2.Text + " ', ' " + DropDownList3.Text + " ', ' " + aadhar.Text + " ')", cn);
            cn.Open();

            int i = cmd.ExecuteNonQuery();
            if (i > 0)
            {
                msg2.Text = "Registered Successfully";
                Response.Redirect("patientresp.aspx");

            }
        }
    
}
}