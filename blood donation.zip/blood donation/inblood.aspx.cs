﻿using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using System;

namespace blood_donation
{
    public partial class inblood : System.Web.UI.Page
    {
        string conn = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {


        }
        void display()
        {
            SqlConnection cn = new SqlConnection(conn);
            SqlCommand cmd = new SqlCommand("select d.Id,d.name,g.GroupName,o.Quantity,o.Unit,o.Date from Donor_table d join InBlood o on d.id=o.Donorid join BloodGroup g on d.bloodgp=g.Id where d.id='" + did.Text + " '", cn);
            cn.Open();
            SqlDataAdapter adop = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adop.Fill(ds);
            GridView1.DataSource = ds;

            GridView1.DataBind();
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection cn = new SqlConnection(conn);
                SqlCommand cmd = new SqlCommand("insert into InBlood(Donorid,Quantity,Unit,Date) values(' " + did.Text + " ', ' " + quant.Text + " ', ' " + unit.Text + " ', ' " + date.Text + " ')", cn);
                cn.Open();

                cmd.ExecuteNonQuery();
                cn.Close();
                Label1.Text = "Inserted Successfully";
                display();
                cn.Open();
                SqlCommand cnd = new SqlCommand("select g.GroupName from Donor_table d join BloodGroup g on d.bloodgp=g.id where d.id='" + did.Text + "'  ", cn);
                string a = Convert.ToString(cnd.ExecuteScalar());
                SqlCommand cdd = new SqlCommand("select Quantity from BloodBank where BloodGroup='" + a + "'", cn);
                int quantt = (int)cdd.ExecuteScalar();
                //int mainquan = 0;                       
                //int quantt = 0;
                int txt = int.Parse(quant.Text);
                quantt = quantt + txt;

                SqlCommand cd = new SqlCommand("update BloodBank set Quantity='" + quantt + "' where BloodGroup='" + a + "'", cn);
                cd.ExecuteNonQuery();
                Bind();

            }
            catch (Exception)
            {
                Label1.Text = "Please check Ur Data";
            }

        }

        public void Bind()
        {
            SqlConnection cn = new SqlConnection(conn);
            SqlCommand cmd = new SqlCommand("select * from BloodBank", cn);
            cn.Open();
            SqlDataAdapter adop = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adop.Fill(ds);
            GridView2.DataSource = ds;

            GridView2.DataBind();
        }


    }
}