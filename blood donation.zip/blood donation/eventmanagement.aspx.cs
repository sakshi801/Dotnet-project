﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace blood_donation
{
    public partial class eventmanagement : System.Web.UI.Page
    {
        string conn = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                
                Bind();
            }

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Calendar1.Visible = true;
        }

        protected void Calendar1_SelectionChanged(object sender, EventArgs e)
        {
            TextBox2.Text = (Calendar1.SelectedDate.ToShortDateString() + " " + TextBox1.Text + " " + AM.SelectedItem).ToString();
            Calendar1.Visible = false;

        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            SqlConnection cn = new SqlConnection(conn);
            SqlCommand cmd = new SqlCommand("insert into camp(DateTime,Venue,Purpose) values(' " + TextBox2.Text + " ',  ' " + TextBox3.Text + " ',  ' " + TextBox4.Text + " ')", cn);
            cn.Open();
            int i = cmd.ExecuteNonQuery();
            if (i > 0)
            {

                msg2.Text = "success";
                TextBox1.Text = "";
                TextBox2.Text = "";
                TextBox3.Text = "";
                TextBox4.Text = "";
                
                Bind();


            }
        }

        public void Bind()
        {
            SqlDataAdapter ad = new SqlDataAdapter("select * from camp", conn);
            DataTable dt = new DataTable();
            ad.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();
        }

        protected void deleteclk(object sender, EventArgs e)
        {
            int ID = int.Parse((sender as LinkButton).CommandArgument);
            SqlConnection cn = new SqlConnection(conn);
            cn.Open();
            SqlCommand cnd = new SqlCommand("delete from camp where Id='" + ID + "'", cn);
            int i = cnd.ExecuteNonQuery();
            Bind();
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox3.Text = "";
            TextBox4.Text = "";
            
            msg2.Text = "";

        }

        protected void GridView1_RowEditing(object sender, GridViewEditEventArgs e)
        {
            GridView1.EditIndex = e.NewEditIndex;
            Bind();
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox3.Text = "";
            TextBox4.Text = "";

            msg2.Text = "";

        }

        protected void GridView1_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {

            Label Id = GridView1.Rows[e.RowIndex].FindControl("lbl1") as Label;
            TextBox date = (TextBox)GridView1.Rows[e.RowIndex].FindControl("Txt1");
            TextBox venue = (TextBox)GridView1.Rows[e.RowIndex].FindControl("Txt2");
            TextBox purpose = (TextBox)GridView1.Rows[e.RowIndex].FindControl("Txt3");
      
            
            SqlConnection cn = new SqlConnection(conn);
            cn.Open();
            SqlCommand cmmd = new SqlCommand("update camp set DateTime='" + date.Text + "',Venue='" + venue.Text + "',Purpose='" + purpose.Text + "' where id='" + Id.Text + "'", cn);
            cmmd.ExecuteNonQuery();
            GridView1.EditIndex = -1;
            Bind();



        }

        protected void GridView1_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            GridView1.EditIndex = -1;
            Bind();
            msg2.Text = "success";
            TextBox1.Text = "";
            TextBox2.Text = "";
            TextBox3.Text = "";
            TextBox4.Text = "";
            
        }

        

        protected void Button3_Click1(object sender, EventArgs e)
        {
            string purposee = TextBox5.Text;
            SqlDataAdapter ad = new SqlDataAdapter("select * from camp where Purpose='" + purposee + "' ", conn);
            DataTable dt = new DataTable();
            ad.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();

        }

        protected void Button4_Click1(object sender, EventArgs e)
        {
            SqlDataAdapter ad = new SqlDataAdapter("select * from camp", conn);
            DataTable dt = new DataTable();
            ad.Fill(dt);
            GridView1.DataSource = dt;
            GridView1.DataBind();

        }
    }
}