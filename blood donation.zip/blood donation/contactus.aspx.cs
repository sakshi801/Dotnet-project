﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace blood_donation
{
    public partial class contactus : System.Web.UI.Page
    {
        string conn = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection cn = new SqlConnection(conn);
            SqlCommand cmd = new SqlCommand("insert into feedback(Name,Email,Query) values(' " +TextBox1.Text+ " ', ' " + TextBox2.Text + " ', ' " + TextArea1.InnerText + " ')", cn);
            cn.Open();
            int i = cmd.ExecuteNonQuery();
            if (i > 0)
            {

                Label1.Text = "Thanks for your Response";
                TextBox1.Text = "";
                TextBox2.Text = "";
                TextArea1.InnerText = "";


            }

           
        }
    }
}