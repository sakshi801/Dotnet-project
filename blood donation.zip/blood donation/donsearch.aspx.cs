﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace blood_donation
{
    public partial class donsearch : System.Web.UI.Page
    {
        string conn = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                dropbgbind();
                dropbtbind();
               
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string searchbycity = Drop.Text;
            string searchbybg = Dropbgrp.SelectedValue;
            string searchbybt = Dropbtyp.SelectedValue;

            SqlConnection cn = new SqlConnection(conn);
            SqlCommand cmd = new SqlCommand("select * from Donor_table where city='" + searchbycity + "'  "  , cn);
            cn.Open();
            SqlDataAdapter adop = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adop.Fill(ds);
            GridView1.DataSource = ds;

            GridView1.DataBind();
        }





        void dropbgbind()
        {
            SqlConnection cn = new SqlConnection(conn);
            SqlCommand cmd = new SqlCommand("select * from BloodGroup", cn);
            cn.Open();
            SqlDataAdapter adop = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adop.Fill(ds);
            Dropbgrp.DataSource = ds;
            Dropbgrp.DataTextField = "GroupName";
            Dropbgrp.DataValueField = "Id";
            Dropbgrp.DataBind();
        }

        void dropbtbind()
        {
            SqlConnection cn = new SqlConnection(conn);
            SqlCommand cmd = new SqlCommand("select * from BloodType", cn);
            cn.Open();
            SqlDataAdapter adop = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adop.Fill(ds);
            Dropbtyp.DataSource = ds;
            Dropbtyp.DataTextField = "BloodName";
            Dropbtyp.DataValueField = "Id";
            Dropbtyp.DataBind();
        }
    }
}
