﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace blood_donation
{
    public partial class eventdisplay : System.Web.UI.Page
    {
         string conn = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;

            protected void Page_Load(object sender, EventArgs e)
            {


            if (!IsPostBack)
            {
                display();
            }


        }






            void display()
            {
                SqlConnection cn = new SqlConnection(conn);
                SqlCommand cmd = new SqlCommand("select * from camp", cn);
                cn.Open();
                SqlDataAdapter adop = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                adop.Fill(ds);
                GridView1.DataSource = ds;

                GridView1.DataBind();
            }


        }
    }
