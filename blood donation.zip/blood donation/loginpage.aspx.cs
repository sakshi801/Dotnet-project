﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace blood_donation
{
    public partial class loginpage : System.Web.UI.Page
    {
        string conn = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection cn = new SqlConnection(conn);
            SqlCommand cmd = new SqlCommand("select * from login where userid = ' " + TextBox1.Text + " ' and password= ' " + TextBox2.Text + " '  ", cn);
            cn.Open();

            SqlDataReader rd = cmd.ExecuteReader();

            if (rd.Read())
            {
                Response.Redirect("Home1.aspx");
            }

            else
            {
                msg.Text = "Id and Password are incorrect";
            }

        }

        
    }
}