﻿using System;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace blood_donation
{
    public partial class _out : System.Web.UI.Page
    {
        string conn = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;

        protected void Page_Load(object sender, EventArgs e)
        {

        }


        void display()
        {
            SqlConnection cn = new SqlConnection(conn);
            SqlCommand cmd = new SqlCommand("select o.Id,d.name,g.GroupName,o.Quantity,o.Unit,o.Date from Patient_table d join OutBlood o on d.id=o.Patientid join BloodGroup g on d.bloodgp=g.Id where o.id='" + did.Text + " '", cn);
            cn.Open();
            SqlDataAdapter adop = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adop.Fill(ds);
            GridView1.DataSource = ds;

            GridView1.DataBind();
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection cn = new SqlConnection(conn);
                SqlCommand cmd = new SqlCommand("insert into OutBlood(Patientid,Quantity,Unit,Date) values(' " + did.Text + " ', ' " + quant.Text + " ', ' " + unit.Text + " ', ' " + date.Text + " ')", cn);
                cn.Open();

                cmd.ExecuteNonQuery();
                cn.Close();
                Label1.Text = "Inserted Successfully";
                display();
                cn.Open();
                SqlCommand cnd = new SqlCommand("select g.GroupName from Patient_table d join BloodGroup g on d.bloodgp=g.id where d.id='" + did.Text + "'  ", cn);
                string a = Convert.ToString(cnd.ExecuteScalar());
                SqlCommand cdd = new SqlCommand("select Quantity from BloodBank where BloodGroup='" + a + "'", cn);
                int quantt = (int)cdd.ExecuteScalar();
                int txt = int.Parse(quant.Text);
                if (quantt == 0 && txt > quantt)
                {
                    Label2.Text = "No Blood is available to Take.";
                }
                else
                {

                    quantt = quantt - txt;
                    SqlCommand cd = new SqlCommand("update BloodBank set Quantity='" + quantt + "' where BloodGroup='" + a + "'", cn);
                    cd.ExecuteNonQuery();

                }
               
            }
            catch (Exception)
            {
                Label1.Text = "Please check ur data";
            }

        }
    }
}