﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace blood_donation
{
    public partial class donorreg : System.Web.UI.Page
    {

        string conn = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;



        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                dropbgbind();
                dropbtbind();
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            SqlConnection cn = new SqlConnection(conn);
            SqlCommand cmd = new SqlCommand("insert into Donor_table(name,Gender,age,Weight,mob,email,bloodgp,country,state,city,aadhar,BloodType,Date) values(' " + dname.Text + " ', ' " + RadioButtonList1.Text + " ', ' " + age.Text + " ', ' " + weight.Text + " ', ' " + mob.Text + " ',' " + email.Text + " ', ' " + Dropbgrp.SelectedValue + " ', ' " + DropDownList1.Text + " ', ' " + DropDownList2.Text + " ', ' " + DropDownList3.Text + " ', ' " + aadhar.Text + " ' , ' " + Dropbtyp.SelectedValue + " ' , ' " + cal.Text + " ')", cn);
            cn.Open();
            int i = cmd.ExecuteNonQuery();
            if (i > 0)
            {
                
                Response.Redirect("donorresp.aspx");


            }
        }

        void dropbgbind()
        {
            SqlConnection cn = new SqlConnection(conn);
            SqlCommand cmd = new SqlCommand("select * from BloodGroup", cn);
            cn.Open();
            SqlDataAdapter adop = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adop.Fill(ds);
            Dropbgrp.DataSource = ds;
            Dropbgrp.DataTextField = "GroupName";
            Dropbgrp.DataValueField = "Id";
            Dropbgrp.DataBind();
        }

        void dropbtbind()
        {
            SqlConnection cn = new SqlConnection(conn);
            SqlCommand cmd = new SqlCommand("select * from BloodType", cn);
            cn.Open();
            SqlDataAdapter adop = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adop.Fill(ds);
            Dropbtyp.DataSource = ds;
            Dropbtyp.DataTextField = "BloodName";
            Dropbtyp.DataValueField = "Id";
            Dropbtyp.DataBind();
        }

    }
}