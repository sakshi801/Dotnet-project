﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace blood_donation
{
    public partial class searchad : System.Web.UI.Page
    {
        string conn = ConfigurationManager.ConnectionStrings["connection"].ConnectionString;
        string bg;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                dropbgbind();


            }
        }
        protected void Button1_Click(object sender, EventArgs e)
        {
            string a = Dropbgrp.SelectedValue;

            if (a == "1")
            {
                bg = "A+";
            }
            else if (a == "2")
            {
                bg = "O+";
            }
            else if (a == "3")
            {
                bg = "B+";
            }
            else if (a == "4")
            {
                bg = "AB+";
            }
            else if (a == "5")
            {
                bg = "A-";
            }
            else if (a == "6")
            {
                bg = "O-";
            }
            else if (a == "7")
            {
                bg = "B-";
            }
            else if (a == "8")
            {
                bg = "AB-";
            }
            SqlConnection cn = new SqlConnection(conn);
            cn.Open();
            SqlCommand cdd = new SqlCommand("select Quantity from BloodBank where BloodGroup='" + bg + "'", cn);
            int quantt = (int)cdd.ExecuteScalar();
            if (quantt == 0)
            {
                Label1.Text = "Blood Not Availaable";
                GridView1.DataSource = null;
                GridView1.DataBind();

            }
            else
            {
                SqlCommand cmd = new SqlCommand("select * from BloodBank where BloodGroup='" + bg + "'  ", cn);

                SqlDataAdapter adop = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                adop.Fill(ds);
                GridView1.DataSource = ds;

                GridView1.DataBind();
                Label1.Text = "";
            }


        }
        void dropbgbind()
        {
            SqlConnection cn = new SqlConnection(conn);
            SqlCommand cmd = new SqlCommand("select * from BloodGroup", cn);
            cn.Open();
            SqlDataAdapter adop = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            adop.Fill(ds);
            Dropbgrp.DataSource = ds;
            Dropbgrp.DataTextField = "GroupName";
            Dropbgrp.DataValueField = "Id";
            Dropbgrp.DataBind();
        }

    }
}